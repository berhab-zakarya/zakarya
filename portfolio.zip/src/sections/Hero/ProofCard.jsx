import CtaButton from "../../components/ui/CtaButton.jsx";

export default function ProofCard({ title, rows, cta, href }) {
  return (
    <aside className="proof" aria-labelledby="proof-title">
      <h2 id="proof-title" className="proof__title">{title}</h2>
      {rows.map(([value, label]) => (
        <div className="proof__row" key={value}><strong>{value}</strong><span>{label}</span></div>
      ))}
      <CtaButton variant="dark" className="proof__cta" href={href} label={cta} />
    </aside>
  );
}
