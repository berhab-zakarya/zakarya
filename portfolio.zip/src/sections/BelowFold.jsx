import Section from "../components/layout/Section.jsx";

/* Everything under the hero lives in this lazily loaded chunk so the first paint only ships the hero.
   When these sections get real content, give each its own folder and its own lazy() import. */
export default function BelowFold() {
  return (
    <>
      <Section id="work" title="Selected work" />
      <Section id="services" tone="surface" title="Services" />
      <Section id="about" title="About" />
      <Section id="contact" tone="surface" title="Let's build something" />
    </>
  );
}
