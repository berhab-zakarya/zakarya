/* All copy and placeholder data live here. Replace placeholders with real, verified content. */
export const site = {
  brand: "Zakarya",
  contactHref: "#contact", // swap for a real route or mailto:
  nav: [
    { label: "Work", href: "#work" },
    { label: "Services", href: "#services" },
    { label: "About", href: "#about" },
    { label: "Contact", href: "#contact" },
  ],
  hero: {
    eyebrow: "INDEPENDENT FULL-STACK DEVELOPER",
    tag: "STARTUP PARTNER",
    // strings render plain, { b } renders in the accent colour
    lines: [["I build"], [{ b: "startups" }, " from"], [{ b: "idea to reality." }]],
    lead: "From MVPs to production-ready platforms, I design and build the software that helps ambitious founders launch, validate, and grow.",
    cta: "Let's build something",
    cardCta: "Discuss your project",
    proofTitle: "SELECTED EXPERIENCE",
    proof: [
      ["[X]+", "Products and projects delivered"],
      ["End-to-end", "From product architecture to deployment"],
      ["Full-stack", "Frontend, backend, databases and integrations"],
    ],
    logosTitle: "Selected collaborations",
    logosCopy: "Founders, teams, and products I've helped bring to life.",
    logos: [
      ["[Startup One]", "w1"], ["[Client Two]", "w2"], ["[Product Three]", "w3"], ["[Company Four]", "w4"],
      ["[Project Five]", "w5"], ["[Brand Six]", "w6"], ["[Studio Seven]", "w2"], ["[Venture Eight]", "w1"],
    ],
  },
};
