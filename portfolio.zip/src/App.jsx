import { lazy, Suspense } from "react";
import SiteHeader from "./components/layout/SiteHeader.jsx";
import Hero from "./sections/Hero/Hero.jsx";
import { site } from "./content/site.js";

// Hero is eager (it is the LCP). Everything below is split into its own chunk.
const BelowFold = lazy(() => import("./sections/BelowFold.jsx"));

export default function App() {
  return (
    <>
      <SiteHeader brand={site.brand} nav={site.nav} cta={site.hero.cta} ctaHref={site.contactHref} />
      <main>
        <Hero content={site.hero} contactHref={site.contactHref} />
        <Suspense fallback={<div className="below-fold-fallback" aria-hidden="true" />}>
          <BelowFold />
        </Suspense>
      </main>
    </>
  );
}
