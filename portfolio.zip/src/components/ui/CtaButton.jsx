import ArrowIcon from "./ArrowIcon.jsx";
import "./CtaButton.css";

/** Blue label + separate white arrow square. variant: "light" (on light bg) | "dark" (inside black card) */
export default function CtaButton({ href, label, variant = "light", className = "" }) {
  return (
    <a className={`btn btn--${variant} ${className}`} href={href}>
      <span className="btn__label">{label}</span>
      <span className="btn__arrow"><ArrowIcon /></span>
    </a>
  );
}
