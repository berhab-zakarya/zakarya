# Portfolio

    npm install
    npm run dev

- `src/content/site.js`: all copy and placeholders (replace with real, verified info)
- `src/styles/tokens.css`: colours, spacing, fonts and the z-index scale
- `src/components/ui|layout`: reusable pieces (CtaButton, Section, SiteHeader)
- `src/sections/<Name>/`: one folder per page section; register it in `App.jsx`
- Hero ribbon: `ribbonField.js` (pure field + painter) and `DotRibbon.jsx` (canvas + pointer interaction)

Adding a section: create `src/sections/Foo/Foo.jsx` (+ `.css`), then use `<Section id="foo">` or your own markup in `App.jsx`.
Layering: use the `--z-*` variables from tokens.css, never raw numbers.

## Performance notes
- Hero is eager (LCP); everything below it is a lazy chunk (`sections/BelowFold.jsx`). Give heavy future sections their own `lazy()` import.
- React is a separate vendor chunk (`vite.config.js`) so it stays cached across deploys.
- Outfit is self-hosted via `@fontsource-variable/outfit` (no third-party request; only needed unicode subsets download).
- Below-the-fold `.section` uses `content-visibility: auto`.
- Ribbon: pointer state lives in refs (no React renders), the field rebuilds only when width / capped height change (debounced),
  the rAF loop runs only while the pointer is active, and the backing store is capped at ~5M pixels.
- Don't wrap things in `memo`/`useMemo` by default: App has no state, so nothing re-renders. Measure first.
